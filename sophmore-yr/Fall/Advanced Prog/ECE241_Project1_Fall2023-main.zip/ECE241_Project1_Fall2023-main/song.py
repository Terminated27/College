class Song:
    def __init__(self, artist_name: str, song_title: str, song_id: str, duration: float, year: int):
        """

        :param artist_name:
        :param song_title:
        :param song_id:
        :param duration:
        :param year:
        :return:
        """
        pass

    def __str__(self):
        """

        :return:
        """

        return "PLEASE REPLACE THIS STRING FOLLOW THE INSTRUCTION"

    def play(self):
        """

        :return:
        """
        pass
