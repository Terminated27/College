class Book:
    ## to complete





def main():
    book1=Book("A Brief History of Time","Stephen Hawking",10.17,"GV5N32M9")
    print(book1)

if __name__=="__main__":
    main()
