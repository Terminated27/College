from Book import Book


class Inventory:

    # To complete

