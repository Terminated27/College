###############################
# Team members- Please enter your names here
# Name1:
# Name2:
###############################

# Modules
from Inventory import Inventory




'''------------------------------------------------------
                Main program starts here 
---------------------------------------------------------'''
# to complete

