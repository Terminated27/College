#!/bin/bash

# Filename: ex10.sh
#
# Problem: Use a loop to count from 1 to 10



for i in $(seq 10)
do
	echo Count is: $i
done
