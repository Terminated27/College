#!/bin/bash

# Filename: ex14.sh
#
# Problem: Run the awk script ex14.awk, it will provide instructions for setting
# up the test case. Then add a script in this file to print Hello.
echo "Hello"
